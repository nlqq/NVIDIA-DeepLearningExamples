#!/bin/bash

cp ../common/* .
bash run_test.sh distributed $1

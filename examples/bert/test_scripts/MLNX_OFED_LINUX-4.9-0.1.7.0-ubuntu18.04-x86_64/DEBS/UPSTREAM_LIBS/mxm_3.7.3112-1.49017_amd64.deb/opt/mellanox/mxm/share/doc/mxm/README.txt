*** What is MXM?

	MXM is a MellanoX Messaging library which is integrated with major MPI 
	distributions and provides best of breed performance and scalability for HPC applications.

** What are MXM requirements?

	- Mellanox OFED 1.5.3 or later
	- OpenMPI 1.6 or later


*** How to compile OpenMPI with MXM?

	1. Install MXM from RPM

	% rpm -ihv mxm-x.y.z-1.x86_64.rpm

	- MXM will be installed automatically in the /opt/mellanox/mxm folder.

	2. Enter OpenMPI source directory and issue following configure line:

	% cd $OMPI_HOME
	% ./configure --with-mxm=/opt/mellanox/mxm <... other configure parameters...>
	% make all && make install

*** What MXM parameters can be tuned?

	Run /opt/mellanox/mxm/bin/mxm_dump_config utility which is part of mxm rpm. It
	will print all available MXM parameters which can be modified in the user environment.

	For example:

	% /opt/mellanox/mxm/bin/mxm_dump_config | less


	% mpirun -x MXM_UD_RX_MAX_BUFFERS=128000 <...>

	or

	% export MXM_UD_RX_MAX_BUFFERS=128000
	% mpirun <...>

*** How to run OMPI w/o mxm

	% mpirun -mca mtl ^mxm <...>

